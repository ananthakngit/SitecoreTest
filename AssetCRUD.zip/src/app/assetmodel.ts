export class AssetModel {
    Id?:number;
    assetid?: string;
    filename?: string;
    mimetype?: string;
    createdby?: Date;
    email?: string;
    country?: string;
    description?: string;   
  }




