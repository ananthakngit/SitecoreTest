﻿using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;

namespace GeneralKnowledge.Test.App.Tests
{
    /// <summary>
    /// CSV processing test
    /// </summary>
    public class CsvProcessingTest : ITest
    {
        public void Run()
        {
            // TODO
            // Create a domain model via POCO classes to store the data available in the CSV file below
            // Objects to be present in the domain model: Asset, Country and Mime type
            // Process the file in the most robust way possible
            // The use of 3rd party plugins is permitted

            var csvFile = Resources.AssetImport;
            DataTable dt = new DataTable();
            dt.Columns.AddRange(new DataColumn[7]
            { new DataColumn("asset id", typeof(string)),
              new DataColumn("file_name", typeof(string)),
              new DataColumn("mime_type", typeof(string)),
              new DataColumn("created_by", typeof(string)),
              new DataColumn("email", typeof(string)),
              new DataColumn("country", typeof(string)),
              new DataColumn("description",typeof(string)) });

            //Execute a loop over the rows.
            foreach (string row in csvFile.Split('\n'))
            {
                if (!string.IsNullOrEmpty(row))
                {
                    dt.Rows.Add();
                    int i = 0;
                    //Execute a loop over the columns.                   
                    var cells = row.Split(',');
                    for (int x = 0; x < 7; x++)
                    {
                        dt.Rows[dt.Rows.Count - 1][i] = cells[x];
                        i++;

                    }
                }
            }

            SaveDataTabletoDB(dt);
        }


        public void SaveDataTabletoDB(DataTable dt)
        {
            if (dt.Rows.Count > 0)
            {
                string consString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=AssetDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
                using (SqlConnection con = new SqlConnection(consString))
                {
                    using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(con))
                    {
                        //Set the database table name
                        sqlBulkCopy.DestinationTableName = "dbo.Assettbl";

                        //[OPTIONAL]: Map the DataTable columns with that of the database table
                        sqlBulkCopy.ColumnMappings.Add("asset id", "assetid");
                        sqlBulkCopy.ColumnMappings.Add("file_name", "filename");
                        sqlBulkCopy.ColumnMappings.Add("mime_type", "mimetype");
                        sqlBulkCopy.ColumnMappings.Add("created_by", "createdby");
                        sqlBulkCopy.ColumnMappings.Add("email", "email");
                        sqlBulkCopy.ColumnMappings.Add("country", "country");
                        sqlBulkCopy.ColumnMappings.Add("description", "description");
                        con.Open();
                        sqlBulkCopy.WriteToServer(dt);
                        con.Close();
                    }
                }
            }
        }
    }

}
