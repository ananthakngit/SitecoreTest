import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AssetserviceService } from '../assetservice.service';
import { AssetModel } from '../assetmodel';
@Component({
  selector: 'app-assetdetails',
  templateUrl: './assetdetails.component.html',
  styleUrls: ['./assetdetails.component.css']
})
export class AssetdetailsComponent implements OnInit {

  currentAsset = new AssetModel();
  message = '';

  constructor(
    private assetService: AssetserviceService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.message = '';
    this.getAsset(this.route.snapshot.paramMap.get('id'));
  }

  getAsset(id:any): void {
    this.assetService.read(id)
      .subscribe(
        asset => {
          this.currentAsset = asset;
          console.log(asset);
        },
        error => {
          console.log(error);
        });
  }



}
