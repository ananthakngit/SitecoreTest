import { Component, OnInit } from '@angular/core';
import { AssetserviceService } from '../assetservice.service';
import { AssetModel } from '../assetmodel';

@Component({
  selector: 'app-assetlist',
  templateUrl: './assetlist.component.html',
  styleUrls: ['./assetlist.component.css']
})
export class AssetlistComponent implements OnInit {

  assets: any;
  currentAsset = new AssetModel();
  currentIndex = -1;
  name = '';

  constructor(private assetService: AssetserviceService) { }

  ngOnInit(): void {
    this.readAssets();
  }

  readAssets(): void {
    this.assetService.readAll()
      .subscribe(
        assets => {
          this.assets = assets;
          console.log(assets);
        },
        error => {
          console.log(error);
        });
  }

  refresh(): void {
    this.readAssets();
    this.currentAsset = new AssetModel();
    this.currentIndex = -1;
  }

  setCurrentAsset(asset:any, index:number): void {
    this.currentAsset = asset;
    this.currentIndex = index;
  }

}
