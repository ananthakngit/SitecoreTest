import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AssetlistComponent } from './assetlist/assetlist.component';
import { AssetdetailsComponent } from './assetdetails/assetdetails.component';

const routes: Routes = [
  { path: '', redirectTo: 'assetlist', pathMatch: 'full' },
  { path: 'assetlist', component: AssetlistComponent },
  { path: 'assetdetails/:id', component: AssetdetailsComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
