﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebExperience.Test.Models;
namespace WebExperience.Test.Controllers
{
    public class AssetController : ApiController
    {
        // TODO
        // Create an API controller via REST to perform all CRUD operations on the asset objects created as part of the CSV processing test
        // Visualize the assets in a paged overview showing the title and created on field
        // Clicking an asset should navigate the user to a detail page showing all properties
        // Any data repository is permitted
        // Use a client MVVM framework

        static readonly IAssetRepository repository = new AssetRepository();

        //This action method return all members records.  
        // GET api/<controller>  

        public IEnumerable<Assettbl> Get()
        {
          
            return  repository.GetAll();
        }



        //This action method will fetch and filter for specific member id record  
        // GET api/<controller>/5  
        public HttpResponseMessage Get(int id)
        {

            Assettbl item = repository.Get(id); 

            //checking fetched or not with the help of NULL or NOT.  
            if (item != null)
            {
               
                return Request.CreateResponse(HttpStatusCode.OK, item);
            }
            else
            {
                 
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid Code or Member Not Found");
            }
        }


        //To add a new member record  
        // POST api/<controller>  
        public HttpResponseMessage Post([FromBody] Assettbl item)
        {
            try
            {
                item = repository.Add(item);             
                var msg = Request.CreateResponse(HttpStatusCode.Created, item);
                return msg;
            }
            catch (Exception ex)
            {               
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
        }



        //To update member record  
        // PUT api/<controller>/5  
        public HttpResponseMessage Put(int id, [FromBody] Assettbl item)
        {
            
            if (!repository.Update(item))
            {
                throw new HttpResponseException(HttpStatusCode.NotFound);
            }
            else
            {
               
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid Code or Member Not Found");
            }


        }

        // DELETE api/<controller>/5  
        public HttpResponseMessage Delete(int id)
        {
            try
            {
                //fetching and filter specific member id record   
                Assettbl item = repository.Get(id);
                if (item == null)
                {
                    repository.Remove(id);
                }
                return Request.CreateResponse(HttpStatusCode.OK, id);
            }

            catch (Exception ex)
            {

                //return response error as bad request  with exception message.  
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }

        }
    }
}
