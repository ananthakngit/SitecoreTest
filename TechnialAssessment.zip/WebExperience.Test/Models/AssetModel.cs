﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebExperience.Test.Models
{
    public class AssetModel
    {
        public int Id { get; set; }
        public string assetid { get; set; }
        public string filename { get; set; }
        public string mimetype { get; set; }
        public string createdby { get; set; }
        public string email { get; set; }
        public string country { get; set; }
        public string description { get; set; }

    }
}