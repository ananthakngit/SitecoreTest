﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
namespace WebExperience.Test.Models
{
    public class AssetRepository:IAssetRepository
    {
        private List<AssetModel> assetModels = new List<AssetModel>();
        private int _nextId = 1;
        private AssetDBEntities dbcontext = new AssetDBEntities();

        public AssetRepository()
        {
            
        }

        public IEnumerable<Assettbl> GetAll()
        {
            return dbcontext.Assettbls.ToList();
        }

        public Assettbl Get(int id)
        {
            return dbcontext.Assettbls.SingleOrDefault(p => p.Id == id);
        }

        public Assettbl Add(Assettbl item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }
            item.Id = _nextId++;
            dbcontext.Assettbls.Add(item);
            dbcontext.SaveChanges();
            return item;
        }

        public void Remove(int id)
        {
            var ass=  dbcontext.Assettbls.SingleOrDefault(p => p.Id == id);
            dbcontext.Assettbls.Remove(ass);
        }

        public bool Update(Assettbl item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }
            dbcontext.Assettbls.Add(item);
            dbcontext.Entry(item).State = System.Data.Entity.EntityState.Modified;
            dbcontext.SaveChanges();
            return true;
        }
    }
}