﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebExperience.Test.Models
{
    public interface IAssetRepository
    {
        IEnumerable<Assettbl> GetAll();
        Assettbl Get(int id);
        Assettbl Add(Assettbl item);
        void Remove(int id);
        bool Update(Assettbl item);
    }
}