﻿/// <reference path="modernizr-2.8.3.js" />
/// <reference path="jquery-3.3.1.js" />
/// <autosync enabled="true" />
/// <reference path="bootstrap.js" />
/// <reference path="jquery.validate.js" />
/// <reference path="jquery.validate.unobtrusive.js" />
/// <reference path="respond.js" />
